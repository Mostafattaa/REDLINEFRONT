const API_BASE_URL = 'https://dummyjson.com';
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

// Simple in-memory cache
const cache = new Map();

/**
 * Cache utilities
 */
function getCacheKey(endpoint, params) {
  const paramString = params ? JSON.stringify(params) : '';
  return `${endpoint}${paramString}`;
}

function isCacheValid(cacheEntry) {
  if (!cacheEntry) return false;
  return Date.now() - cacheEntry.timestamp < CACHE_DURATION;
}

function getFromCache(key) {
  const cacheEntry = cache.get(key);
  if (isCacheValid(cacheEntry)) {
    return cacheEntry.data;
  }
  cache.delete(key);
  return null;
}

function setCache(key, data) {
  cache.set(key, {
    data,
    timestamp: Date.now()
  });
}

/**
 * Build query string from parameters
 */
export function buildQueryString(params) {
  if (!params || Object.keys(params).length === 0) {
    return '';
  }
  
  const queryParams = new URLSearchParams();
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== '') {
      queryParams.append(key, value);
    }
  });
  
  const queryString = queryParams.toString();
  return queryString ? `?${queryString}` : '';
}

/**
 * Sleep utility for retry delays
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Core fetch wrapper with retry logic
 */
async function fetchWithRetry(url, options = {}, retryCount = 0) {
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
    
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('Resource not found');
      }
      if (response.status === 500) {
        throw new Error('Server error, please try again later');
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      error.message = 'Network error, please check your connection';
    }
    
    if (retryCount < MAX_RETRIES) {
      const delay = RETRY_DELAY * Math.pow(2, retryCount);
      await sleep(delay);
      return fetchWithRetry(url, options, retryCount + 1);
    }
    
    throw error;
  }
}

/**
 * Generic GET request with caching
 */
async function get(endpoint, params = null, useCache = true) {
  const cacheKey = getCacheKey(endpoint, params);
  
  if (useCache) {
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }
  }
  
  const queryString = buildQueryString(params);
  const url = `${API_BASE_URL}${endpoint}${queryString}`;
  
  const data = await fetchWithRetry(url);
  
  if (useCache) {
    setCache(cacheKey, data);
  }
  
  return data;
}

/**
 * Normalize product data from DummyJSON API to match app expectations
 */
function normalizeProduct(product) {
  return {
    ...product,
    // Convert category string to object format
    category: typeof product.category === 'string' 
      ? { name: product.category, slug: product.category }
      : product.category,
    // Ensure images array exists
    images: product.images || [product.thumbnail],
    // Ensure thumbnail exists
    thumbnail: product.thumbnail || product.images?.[0] || ''
  };
}

/**
 * Normalize array of products
 */
function normalizeProducts(products) {
  return products.map(normalizeProduct);
}

/**
 * Get all products with pagination
 */
export async function getAllProducts({ limit = 30, skip = 0, select } = {}) {
  const params = { limit, skip };
  if (select) params.select = select;
  const data = await get('/products', params);
  return normalizeProducts(data.products || []);
}

/**
 * Get single product by ID
 */
export async function getProductById(id) {
  const product = await get(`/products/${id}`);
  return normalizeProduct(product);
}

/**
 * Search products by query
 */
export async function searchProducts(query, { limit, skip, select } = {}) {
  const params = { q: query };
  if (limit !== undefined) params.limit = limit;
  if (skip !== undefined) params.skip = skip;
  if (select) params.select = select;
  const data = await get('/products/search', params);
  return normalizeProducts(data.products || []);
}

/**
 * Get products with sorting
 */
export async function getProductsSorted({ sortBy, order = 'asc', limit = 30, skip = 0 } = {}) {
  const params = { limit, skip };
  if (sortBy) {
    params.sortBy = sortBy;
    params.order = order;
  }
  const data = await get('/products', params);
  return normalizeProducts(data.products || []);
}

/**
 * Get all product categories
 */
export async function getAllCategories() {
  return await get('/products/categories');
}

/**
 * Get category list (slugs only)
 */
export async function getCategoryList() {
  return await get('/products/category-list');
}

/**
 * Get products by category
 */
export async function getProductsByCategory(category, { limit, skip } = {}) {
  const params = {};
  if (limit !== undefined) params.limit = limit;
  if (skip !== undefined) params.skip = skip;
  const data = await get(`/products/category/${category}`, params);
  return normalizeProducts(data.products || []);
}

/**
 * Filter products with multiple criteria (alias for getAllProducts)
 */
export async function filterProducts(filters = {}) {
  return await getAllProducts(filters);
}

/**
 * Get related products by ID (returns random products from same category)
 */
export async function getRelatedProductsById(id) {
  try {
    const product = await getProductById(id);
    // product.category is now normalized to { name, slug }
    const categorySlug = product.category.slug || product.category.name;
    const categoryProducts = await getProductsByCategory(categorySlug, { limit: 10 });
    // Filter out the current product and return up to 4 related products
    return categoryProducts.filter(p => p.id !== parseInt(id)).slice(0, 4);
  } catch (error) {
    console.error('Failed to fetch related products:', error);
    return [];
  }
}

/**
 * Cache management
 */
export function clearCache() {
  cache.clear();
}

export function clearCacheEntry(endpoint, params = null) {
  const key = getCacheKey(endpoint, params);
  cache.delete(key);
}

export function getCacheStats() {
  return {
    size: cache.size,
    entries: Array.from(cache.keys())
  };
}
