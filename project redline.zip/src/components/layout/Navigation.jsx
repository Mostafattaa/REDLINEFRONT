import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CartBadge } from '../cart/CartBadge';
import { MobileMenu } from './MobileMenu';

export function Navigation({ cartCount, user, onLogout, onSearch }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (onSearch && searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  return (
    <nav className="container mx-auto px-4 py-4">
      {/* Desktop navigation */}
      <div className="hidden md:flex items-center justify-evenly gap-x-44">
        {/* Logo */}
        <Link to="/" className="flex items-center flex-shrink-0">
          <img src="/assets/redline.png" alt="E-Commerce Platform" className="h-10" />
        </Link>
        
        {/* Center: Nav Links */}
        <div className="flex items-center gap-8">
          <Link to="/" className="text-gray-700 hover:text-primary-600 font-semibold transition-colors text-lg">
            Home
          </Link>
          <Link to="/products" className="text-gray-700 hover:text-primary-600 font-semibold transition-colors text-lg">
            Products
          </Link>
          <Link to="/about" className="text-gray-700 hover:text-primary-600 font-semibold transition-colors text-lg">
            About
          </Link>
          <Link to="/contact" className="text-gray-700 hover:text-primary-600 font-semibold transition-colors text-lg">
            Contact
          </Link>
        </div>

        {/* Right: Search + Cart + User */}
        <div className="flex items-center gap-4 flex-shrink-0">
          {/* Search Bar */}
          <form onSubmit={handleSearchSubmit} className="w-64">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full px-4 py-2.5 pl-11 pr-4 border-2 border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm hover:border-primary-300 transition-all"
              />
              <svg
                className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
          </form>

          {/* Cart */}
          <Link to="/cart" className="relative">
            <CartBadge count={cartCount} />
          </Link>

          {/* User */}
          {user ? (
            <div className="flex items-center gap-3 pl-4 border-l-2 border-gray-200">
              <span className="text-gray-700 text-sm font-medium">Hello, {user.username}</span>
              <button
                onClick={onLogout}
                className="px-4 py-2 bg-gray-100 hover:bg-primary-50 text-gray-700 hover:text-primary-600 rounded-full font-medium transition-all text-sm"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <Link 
              to="/login" 
              className="px-6 py-2.5 bg-gradient-to-r from-primary-600 to-purple-600 text-white rounded-full font-semibold hover:shadow-lg transition-all transform hover:scale-105"
            >
              Sign In
            </Link>
          )}
        </div>
      </div>

      
      {/* Mobile navigation */}
      <div className="md:hidden flex items-center justify-between">
        <Link to="/" className="flex items-center">
          <img src="/assets/redline.png" alt="E-Commerce Platform" className="h-10" />
        </Link>
        
        <div className="flex items-center gap-4">
          <CartBadge count={cartCount} />
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-gray-700 p-2"
            aria-label="Toggle menu"
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
      
      {mobileMenuOpen && (
        <MobileMenu 
          user={user} 
          onLogout={onLogout}
          onClose={() => setMobileMenuOpen(false)}
          onSearch={onSearch}
        />
      )}
    </nav>
  );
}
