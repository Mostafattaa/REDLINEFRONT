import { useState, useEffect } from 'react';
import { saveAuth, loadAuth, clearAuth as clearAuthStorage } from '../services/storage';

export function useAuth() {
  const [user, setUser] = useState(() => loadAuth());

  // Save auth to sessionStorage whenever it changes
  useEffect(() => {
    if (user) {
      saveAuth(user);
    } else {
      clearAuthStorage();
    }
  }, [user]);

  const login = (userDataOrUsername, password) => {
    // Support both object and separate parameters
    if (typeof userDataOrUsername === 'object') {
      const userData = {
        username: userDataOrUsername.username || userDataOrUsername.email?.split('@')[0],
        email: userDataOrUsername.email,
        isAuthenticated: true
      };
      setUser(userData);
      return true;
    }
    
    // Legacy support: username and password as separate parameters
    if (userDataOrUsername && userDataOrUsername.trim() !== '' && password && password.trim() !== '') {
      const userData = {
        username: userDataOrUsername.trim(),
        isAuthenticated: true
      };
      setUser(userData);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    clearAuthStorage();
  };

  return {
    user,
    isAuthenticated: !!user,
    login,
    logout
  };
}
