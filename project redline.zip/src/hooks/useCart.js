import { useState, useEffect } from 'react';
import { saveCart, loadCart, clearCart as clearCartStorage } from '../services/storage';
import {
  addToCart as addToCartHelper,
  updateCartItemQuantity as updateQuantityHelper,
  removeFromCart as removeFromCartHelper,
  getCartCount,
  calculateTotal,
  calculateSubtotal,
  calculateShipping
} from '../utils/cartHelpers';

export function useCart() {
  const [cart, setCart] = useState([]);
  const [cartCount, setCartCount] = useState(0);

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = loadCart();
    setCart(savedCart);
    setCartCount(getCartCount(savedCart));
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    saveCart(cart);
    setCartCount(getCartCount(cart));
  }, [cart]);

  const addToCart = (product) => {
    setCart(prevCart => addToCartHelper(prevCart, product));
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      removeItem(productId);
    } else {
      setCart(prevCart => updateQuantityHelper(prevCart, productId, newQuantity));
    }
  };

  const removeItem = (productId) => {
    setCart(prevCart => removeFromCartHelper(prevCart, productId));
  };

  const clearCart = () => {
    setCart([]);
    clearCartStorage();
  };

  const subtotal = calculateTotal(cart);
  const shipping = calculateShipping(subtotal);
  const total = subtotal + shipping;

  return {
    cart,
    cartCount,
    addToCart,
    updateQuantity,
    removeItem,
    clearCart,
    subtotal,
    shipping,
    total,
    calculateSubtotal
  };
}
